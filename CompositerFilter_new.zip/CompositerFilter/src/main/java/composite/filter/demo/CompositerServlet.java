package composite.filter.demo;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class CompositerServlet
 */
public class CompositerServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public CompositerServlet() {
		super();
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//doGet(request, response);
		
		String type = request.getParameter("type");
		String managerName = request.getParameter("managerName");
		String managerSourceCode = request.getParameter("managerSourceCode");
		
		System.out.println("type:"+type);
		
		List<CompositeData> data = getData();
		DataFilter filter =  new DataFilter();
		//filter.setProductSourceCode(productSourceCode);
		//filter.setInComposite(type);
		filter.setManagerName(managerName);
		filter.setType(type);
		
		List<CompositeData> searchResult = searchData(data, filter);
		request.setAttribute("data", searchResult);
		
		String nextJSP = "/filter.jsp";
		RequestDispatcher dispatcher = getServletContext().getRequestDispatcher(nextJSP);
		dispatcher.forward(request,response);
		
	}

	List<CompositeData> searchData(List<CompositeData> data, DataFilter filter) {
		
		List<CompositeData> resultList =  new ArrayList<>();

		System.out.println("Searching data using filter:"+ filter);
		
		for(CompositeData cdata: data) {
			
			if(filter.getType() != null && !"".equals(filter.getType()) && !cdata.getType().equalsIgnoreCase(filter.getType())) {
				continue;
			}
			
			if(filter.getInComposite() != null && !"".equals(filter.getInComposite()) && !cdata.getInComposite().equalsIgnoreCase(filter.getInComposite())) {
				continue;
			}
			
			if(filter.getProductSourceCode() != null && !"".equals(filter.getProductSourceCode()) && !cdata.getProductSourceCode().equalsIgnoreCase(filter.getProductSourceCode())) {
				continue;
			}
			
			resultList.add(cdata);

		}
		
		return resultList;
		
	}

	public static List<CompositeData> getData() {

		List<CompositeData> dataList = new ArrayList<>();
		CompositeData data = new CompositeData();
		data.setId(1);
		data.setInComposite("NO");
		data.setType("Firm");
		data.setProductSourceCode("ET3");
		data.setManagerName("ETRADE CAPITAL MANAGEMENT");
		dataList.add(data);

		data = new CompositeData();
		data.setId(2);
		data.setInComposite("YES");
		data.setType("Firm");
		data.setProductSourceCode("ET2");
		data.setManagerName("ETRADE CAPITAL MANAGEMENT");
		dataList.add(data);

		data = new CompositeData();
		data.setId(3);
		data.setInComposite("NO");
		data.setType("Firm");
		data.setProductSourceCode("ET3");
		data.setManagerName("ETRADE CAPITAL MANAGEMENT");
		dataList.add(data);

		return dataList;

	}

}
