package composite.filter.demo;

public class DataFilter {

	private String type;
	private String productSourceCode;
	private String inComposite;
	private String managerName;
	
	public String getManagerName() {
		return managerName;
	}

	public void setManagerName(String managerName) {
		this.managerName = managerName;
	}

	public DataFilter() {}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getProductSourceCode() {
		return productSourceCode;
	}

	public void setProductSourceCode(String productSourceCode) {
		this.productSourceCode = productSourceCode;
	}

	public String getInComposite() {
		return inComposite;
	}

	public void setInComposite(String inComposite) {
		this.inComposite = inComposite;
	}

	
	@Override
	public String toString() {
		return "DataFilter [type=" + type + ", productSourceCode=" + productSourceCode + ", inComposite=" + inComposite
				+ "]";
	}
	
}
