import java.util.ArrayList;
import java.util.List;

public class DataApp {

	
	public static List<CompositeData> getData() {
		
		List<CompositeData> dataList =  new ArrayList<>();
		CompositeData data =  new CompositeData();
		data.setId(1);
		data.setInComposite("NO");
		data.setType("Firm");
		data.setProductSourceCode("ET3");
		dataList.add(data);	
		
		data =  new CompositeData();
		data.setId(2);
		data.setInComposite("YES");
		data.setType("Firm");
		data.setProductSourceCode("ET2");
		dataList.add(data);	
		
		data =  new CompositeData();
		data.setId(3);
		data.setInComposite("NO");
		data.setType("Firm");
		data.setProductSourceCode("ET3");
		dataList.add(data);	
		
		return dataList;
		
	}
	
	public static void main(String[] args) {
		DataApp app =  new DataApp();
		
		
		//Get filter values from Request 
		String type="YES";
		String productSourceCode="ET3";
		
		List<CompositeData> data = getData();
		DataFilter filter =  new DataFilter();
		filter.setProductSourceCode(productSourceCode);
		//filter.setInComposite(type);
		
		List<CompositeData> searchResult = app.searchData(data, filter);
		app.showData(searchResult);
	}

	
	private void showData(List<CompositeData> searchResult) {

		if(searchResult == null || searchResult.isEmpty()) {
			System.out.println("No Record found");
		}
		else {
			
			for(CompositeData data: searchResult) {
				System.out.println(data.getType() +"\t"+ data.getProductSourceCode() +"\t"+ data.getInComposite());
			}
		}
		
	}

	public List<CompositeData> searchData(List<CompositeData> data, DataFilter filter) {
		
		List<CompositeData> resultList =  new ArrayList<>();

		System.out.println("Searching data using filter:"+ filter);
		
		for(CompositeData cdata: data) {
			
			if(filter.getType() != null && !"".equals(filter.getType()) && !cdata.getType().equals(filter.getType())) {
				continue;
			}
			
			if(filter.getInComposite() != null && !"".equals(filter.getInComposite()) && !cdata.getInComposite().equals(filter.getInComposite())) {
				continue;
			}
			
			if(filter.getProductSourceCode() != null && !"".equals(filter.getProductSourceCode()) && !cdata.getProductSourceCode().equals(filter.getProductSourceCode())) {
				continue;
			}
			
			resultList.add(cdata);

		}
		
		return resultList;
		
	}
}
