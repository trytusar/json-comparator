
public class CompositeData {

	private Integer id;
	private String type;
	private String productSourceCode;
	private String inComposite;
	
	public CompositeData() {
		
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getProductSourceCode() {
		return productSourceCode;
	}

	public void setProductSourceCode(String productSourceCode) {
		this.productSourceCode = productSourceCode;
	}

	public String getInComposite() {
		return inComposite;
	}

	public void setInComposite(String inComposite) {
		this.inComposite = inComposite;
	}
	
	
}
